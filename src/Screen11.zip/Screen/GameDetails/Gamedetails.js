import React from 'react'
import { useParams } from 'react-router-dom';
import Data from '../SubCatagory/SubCat.json'
import Subcat from '../SubCatagory/SubCat.json'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Link } from 'react-router-dom'
import { faCartArrowDown, faHeart, faHouse } from '@fortawesome/free-solid-svg-icons'

import { Row, Card, Col } from "react-bootstrap";
export default function Gamedetails() {


    const value = useParams();
    console.log("Value in subcat", value);
    let product = Data.Games.find((data) => data.title === value.pname)
  console.log(product);
    return (
      <div>
            <div >
                <img style={{ height: '30%', width: '40%', paddingTop: 15 }}
                    src={product.image} />
                <h5 style={{paddingTop:15}}>{product.title}</h5>
                <text>(Product ID: { product.id })</text>
            </div>
            
            <div>
                <Row xs={1} md={5} className="g-4" style={{ paddingLeft: 50, paddingRight: 50, paddingTop: 15 }} >
                    {Subcat.Games.map((a) =>
                            <Col>
                                <Card>
                                    <Card.Img style={{ height: '60%', width: '70%', alignSelf: "center", paddingTop: 10,paddingBottom:11 }} 
                                    src={a.image} />
                                </Card>
                            </Col>
                    )}
                </Row>
            </div>
            <div style={{flex:1,paddingTop:15}}>
                <text style={{fontWeight:'bold',fontSize:17}}> Rent: ${product.price}</text>
            </div>
            
            <div style={{justifyContent:"space-between",paddingTop:15}}>
                <button style={{marginRight:'10%',backgroundColor:"#5D5B5A)",
                    borderWidth: 0, borderRadius: 4, height: 40, width: 200
                }}
                    onClick={() => alert('Success\n Item Added to cart successfully')}
                >
                <FontAwesomeIcon icon={faHeart} />
                &nbsp;
                    Add to Wishlist </button>
                
                <Link to={`/cartPage/${product.id}`}>
                <button style={{marginRight:'10%',backgroundColor:"rgb(99, 195, 165)",
                    borderWidth: 0, borderRadius: 4, height: 40, width: 200
                }}
                onClick={()=>alert('Success\n Item Added to cart successfully')}
                >
                    <FontAwesomeIcon icon={faCartArrowDown} />&nbsp;
                   
                        Add to Cart </button>
                    </Link>

            </div>
            <div style={{ marginBottom: '2%' }}>
                <br></br>
                <br></br><br></br>
            </div>
      </div>
  )
}

