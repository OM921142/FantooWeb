import React from 'react'

export default function ManageOrder() {
  return (
    <div>ManageOrder</div>
  )
}
