import React from 'react'
import { useParams } from 'react-router-dom';
import Data from '../SubCatagory/SubCat.json'
export default function EventDetails() {
    const value = useParams();
    console.log("in subtrtrcat", value);
   let product = Data.Games.find((data) => data.title === value.cart)
    console.log(product);
  return (
    <div>
      <div style={{marginTop:7,marginRight:11}}>
        <div>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%', backgroundColor: '#eee',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Event Start: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-55%", width: "80%"
              }} />
            </span>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Time: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-85%", width: "80%"
              }} />
            </span>
          </div>
        </div>
        {/* // */}
        <div>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%', backgroundColor: '#eee',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Event End: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-55%", width: "80%"
              }} />
            </span>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Time: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-85%", width: "80%"
              }} />
            </span>
          </div>
        </div>
        {/* // */}
        <div>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%', backgroundColor: '#eee',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Set up: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-55%", width: "80%"
              }} />
            </span>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Time: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-85%", width: "80%"
              }} />
            </span>
          </div>
        </div>
        {/* // */}
        <div>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%', backgroundColor: '#eee',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> # of Guests: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-55%", width: "266%"
              }} />
            </span>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}></text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>

            </span>
          </div>
        </div>
        {/* // */}
        <div>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%', backgroundColor: '#eee',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Event Type: </text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <input style={{
                display: "flex", marginBottom: 15, marginLeft: "-55%", width: "266%"
              }} />
            </span>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}></text>
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>

            </span>
          </div>
        </div>
      </div>
      {/* // */}
      <div>
        <div style={{ marginRight: 11 }}>
          <div style={{
            alignItems: 'center', justifyContent: 'center', display: 'flex',
            flex: 1, marginLeft: '1%',
            padding: 10,
          }}>
            <span style={{
              width: "20%",
              justifyContent: "center",
            }}>
              <text style={{
                display: 'flex',
                marginLeft: '1%', marginBottom: 15
              }}> Special Instructions : </text>
              {/* <img style={{
            display: 'flex',
            marginLeft: '1%', marginBottom: 15
          }} src={product.image}></img> */}
            </span>
            <span style={{
              justifyContent: "center",
              flex: 1,
              paddingLeft: 10,
              marginLeft: 80
            }}>
              <text style={{
                display: "flex", marginBottom: 15, marginLeft: "-25%"
              }}></text>
            </span>
            <span style={{

              justifyContent: "flex-end",
              alignItems: "center",
            }}>


            </span>
          </div>
        </div>
      </div>
      {/* // */}



{/* // */}

      <div style={{marginRight:10}}>
        <div style={{
          alignItems: 'center', justifyContent: 'center', display: 'flex',
          flex: 1, marginLeft: '1%', backgroundColor: '#eee',marginTop:-15,
          padding: 10,
        }}>
          <span style={{
            width: "20%",
            justifyContent: "center",
          }}>
            <text style={{
              display: 'flex',
              marginLeft: '1%', marginBottom: 15
            }}> Special Instructions: </text>
          </span>
          <span style={{
            justifyContent: "center",
            flex: 1,
            paddingLeft: 10,
            marginLeft: 80
          }}>
            <input style={{
              display: "flex", marginBottom: 15, marginLeft: "-55%", width: "266%"
            }} />
          </span>
          <span style={{
            width: "20%",
            justifyContent: "center",
          }}>
            <text style={{
              display: 'flex',
              marginLeft: '1%', marginBottom: 15
            }}></text>
          </span>
          <span style={{
            justifyContent: "center",
            flex: 1,
            paddingLeft: 10,
            marginLeft: 80
          }}>

          </span>
        </div>
      </div>      


{/* // */}
      <div  style={{marginRight:11}}>
        <div style={{
          alignItems: 'center', justifyContent: 'center', display: 'flex',
          flex: 1, marginLeft: '1%',
          padding: 10,
        }}>
          <span style={{
            width: "20%",
            justifyContent: "center",
          }}>
            <text style={{
              display: 'flex',
              marginLeft: '1%', marginBottom: 15
            }}> Games : </text>
            {/* <img style={{
            display: 'flex',
            marginLeft: '1%', marginBottom: 15
          }} src={product.image}></img> */}
          </span>
          <span style={{
            justifyContent: "center",
            flex: 1,
            paddingLeft: 10,
            marginLeft: 80
          }}>
            <text style={{
              display: "flex", marginBottom: 15, marginLeft: "-25%"
            }}></text>
          </span>
          <span style={{

            justifyContent: "flex-end",
            alignItems: "center",
          }}>


          </span>
        </div>
     </div>
      
      
      
      
      
      <div style={{
        alignItems: 'center', justifyContent: 'center', display: 'flex',
        flex: 1, marginLeft: '1%',
        padding: 10, backgroundColor: "#eee", marginRight: 11
      }}>
        <span style={{
          width: "20%",
          justifyContent: "center",
        }}>
          <img style={{
            display: 'flex',
            marginLeft: '1%', marginBottom: 15
          }} src={product.image}></img>
        </span>
        <span style={{
          justifyContent: "center",
          flex: 1,
          paddingLeft: 10,
          marginLeft: 80
        }}>
          <text style={{
            display: "flex", marginBottom: 15, marginLeft: "-25%"
          }}>{product.title}</text></span>
        <span style={{

          justifyContent: "flex-end",
          alignItems: "center",
        }}>
          <text style={{ marginRight: 50 }}> $ {product.price}</text>

        </span>
      </div>
{/* 
      /// */}
      <div style={{ marginBottom: '2%' }}>
        <br></br>
        <br></br><br></br>
      </div>
    </div>
  )
}
