import React from 'react'

export default function Billings() {
  return (
    <div>Billings</div>
  )
}
