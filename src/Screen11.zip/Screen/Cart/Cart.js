import React from 'react'
import { useParams } from 'react-router-dom';
import Data from '../SubCatagory/SubCat.json'
import Subcat from '../SubCatagory/SubCat.json'
import { Link } from 'react-router-dom'

export default function Cart() {
    const value = useParams();
    console.log("Value in subtrtrcat", value);
   let product = Data.Games.find((data) => data.id === value.cart)
    console.log(product);
  return (
      <div>
          <div style={{
              alignItems: 'center', justifyContent: 'center', display: 'flex',
              flex: 1,marginLeft:'1%',
              padding: 10, backgroundColor:"#eee",marginRight:12
          }}>
              <span style={{
                  width: "20%",
                  justifyContent: "center",
              }}>
                  <img style={{
                      display: 'flex',
                      marginLeft: '1%', marginBottom: 15
                  }} src={product.image}></img>
                  </span>
              <span style={{
                  justifyContent: "center",
                  flex: 1,
                  paddingLeft: 10,
                  marginLeft: 80
              }}>
                  <text style={{
                      display: "flex", marginBottom: 15, marginLeft: "-25%"
                  }}>{product.title}</text></span>
          <span style={{

              justifyContent: "flex-end",
                  alignItems: "center", 
          }}>
                  <text style={{marginRight:50}}> $ {product.price}</text>
                  
              </span>
              </div>
            
             
          <div style={{
              alignItems: 'center', justifyContent: 'center', display: 'flex',
              flex: 1,marginTop:'2%',marginLeft:'1%',
              padding: 10, backgroundColor:"#eee",marginRight:12
          }}>
              <span style={{
                  width: "20%",
                  justifyContent: "center",alignItems:'center'
              }}>
                  <text style={{
                      display: 'flex',
                      marginLeft: '1%', marginBottom: 15,alignSelf:"center"
                  }}> Sub Total: </text>
                  </span>
              <span style={{
                  justifyContent: "center",
                  flex: 1,
                  paddingLeft: 10,
                  marginLeft: 80
              }}>
                  {/* <text style={{
                      display: "flex", marginBottom: 15, marginLeft: "-25%"
                  }}>{product.title}</text> */}
                  </span>
          <span style={{

              justifyContent: "flex-end",
                  alignItems: "center", 
          }}>
                  <text style={{marginRight:50}}>${product.price}</text>
                  
              </span>
              </div>
              <div>
           
<div>
<div style={{
              alignItems: 'center', justifyContent: 'center', display: 'flex',
              flex: 1,marginLeft:'1%',
              padding: 10,marginRight:12
          }}>
              <span style={{
                  width: "20%",
                  justifyContent: "center",
              }}>
                  <text style={{
                      display: 'flex',
                      marginLeft: '1%', marginBottom: 15,fontStyle:'italic'
                  }}>* 18% GST will be applicable</text>
                  </span>
              <span style={{
                  justifyContent: "center",
                  flex: 1,
                  paddingLeft: 10,
                  marginLeft: 80
              }}>
                  <text style={{
                      display: "flex", marginBottom: 15, marginLeft: "-25%"
                  }}></text></span>
          <span style={{

              justifyContent: "flex-end",
                  alignItems: "center", 
          }}>
               
                  
              </span>
              </div>
</div>



              <div style={{marginTop:'2%'}}>
              <Link to={`/EventDetails/${product.title}`}>
              <button style={{width:'80%',height:40,borderWidth:0,borderRadius:5,
              backgroundColor:'rgb(99, 195, 165)'}}> 
             <text style={{fontSize:21,color:'white'}}> NEXT </text>
              </button>
                </Link>
                </div>
             
              </div>
      </div>
  )
}
