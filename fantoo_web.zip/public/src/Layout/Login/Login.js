// import React from 'react';
// import { useFormik } from 'formik';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import './Login.css'

// const ValidateForm = (formValue) => {
//     const errors = {};
//    // const reg_exp_email = /^[a-z0-9._%/+-]+@[a-z0-9.-]+\.[a-z]{2,4}$ /

//     if (!formValue.email) {
//         errors.email = "Please enter email";
//         // }else if(!reg_exp_email.test(formValue.email)){
//         //     errors.email="Invalid Email";
//     }
//     if (!formValue.password) {
//         errors.password = "Please enter Password";
//     }
//     console.log("Error:", errors);
//     return errors;
// }
// const Login = () => {


//     const navigate = useNavigate();
//     const lgn = () => {
//         navigate('/')
//     }

//     const home = () => {
//         navigate('/Home')
//     }
//     const formik1 = useFormik({
//         initialValues: {
//             email: '',
//             password: ''
//         },
//         validate: ValidateForm,
//         onSubmit: (values) => {
//             console.log("values Received ", values);

//             axios.post('https://project-node-1.herokuapp.com/postLoginData', values)
//                 .then(res => {
//                     console.log("Axios Response", res);
//                     navigate('/')

//                     window.localStorage.setItem("Token Value:", res.data.token)
//                     alert("you have successfully logged in")
//                 })
//                 .catch(err => {
//                     console.log("Axios error", err);
//                 })
//         }
//     })
//     return (
    
//     <div style={{backgroundColor:'#eee',marginTop:"3%"}}>
//         <form onSubmit={formik1.handleSubmit}>
//         {/* <div style={{marginRight:10}}>
//         <div style={{
//           alignItems: 'center', justifyContent: 'center', display: 'flex',
//           flex: 1, marginLeft: '1%', backgroundColor: '#eee',marginTop:-15,
//           padding: 10,
//         }}>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15,marginLeft: "65%"
//             }}> Username : </text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80,paddingTop:'2%'
//           }}>         
//             <input  style={{
//              marginBottom: 15, marginLeft: "-25%", width: "266%"
//             }} type="text" placeholder="Enter Your username" name="username" value={formik.values.username} onChange={formik.handleChange} onBlur={formik.handleBlur}></input><br></br>
//             {formik.touched.username && formik.errors.username ? <span style={{ color: 'red' }}>{formik.errors.username}</span> : null}
            
//           </span>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15
//             }}></text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80
//           }}>

//           </span>
//         </div>
//       </div>    */}
// {/* // */}

// <div style={{marginRight:10}}>
//         <div style={{
//           alignItems: 'center', justifyContent: 'center', display: 'flex',
//           flex: 1, marginLeft: '1%', backgroundColor: '#eee',marginTop:-15,
//           padding: 10,
//         }}>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",paddingTop:'2%'
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15,marginLeft: "65%"
//             }}> Email: </text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80,paddingTop:'2%'
//           }}>           
//             <input style={{
//              marginBottom: 15, marginLeft: "-25%", width: "266%"
//             }} type="email" placeholder="  name@example.com" name="email" value={formik1.values.email} onChange={formik1.handleChange} onBlur={formik1.handleBlur}></input> <br></br>
//             {formik1.touched.password && formik1.errors.email ? <span style={{ color: 'blue' }}>{formik1.errors.email}</span> : null}
//           </span>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15
//             }}></text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80
//           }}>

//           </span>
//         </div>
//       </div> 

// {/* // */}
            
// <div style={{marginRight:10}}>
//         <div style={{
//           alignItems: 'center', justifyContent: 'center', display: 'flex',
//           flex: 1, marginLeft: '1%', backgroundColor: '#eee',marginTop:-15,
//           padding: 10,
//         }}>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15,marginLeft: "65%",paddingTop:'10%'
//             }}> Password: </text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80,paddingTop:'2%'
//           }}>         
        
            
//             <input  style={{
//              marginBottom: 15, marginLeft: "-25%", width: "266%"
//             }} type="text" placeholder="  Enter Your Password" name="password" value={formik1.values.password} onChange={formik1.handleChange} onBlur={formik1.handleBlur}></input><br></br>
//             {formik1.touched.password && formik1.errors.password ? <span style={{ color: 'red' }}>{formik1.errors.password}</span> : null}



//           </span>
//           <span style={{
//             width: "20%",
//             justifyContent: "center",
//           }}>
//             <text style={{
//               display: 'flex',
//               marginLeft: '1%', marginBottom: 15
//             }}></text>
//           </span>
//           <span style={{
//             justifyContent: "center",
//             flex: 1,
//             paddingLeft: 10,
//             marginLeft: 80
//           }}>

//           </span>
//         </div>
//       </div>            
  
//       <div style={{marginTop:'3%'}}>
//       <button id="BT" type="submit" onClick={home}
//       style={{width:'59%',height:40,borderWidth:0,borderRadius:5,marginLeft:'4%',
//               backgroundColor:'rgb(99, 195, 165)'}}> 
//              <text style={{fontSize:21,color:'white'}}> Submit </text>
//               </button>  
//               <br></br>
//       </div>
            






        

//             {/* Email:
//             <input id="EML" type="email" placeholder="  name@example.com" name="email" value={formik1.values.email} onChange={formik1.handleChange} onBlur={formik1.handleBlur}></input> <br></br>
//             {formik1.touched.password && formik1.errors.email ? <span style={{ color: 'blue' }}>{formik1.errors.email}</span> : null}
//             <br></br>
//             Password:
//             <input id="PWD" type="text" placeholder="  Enter Your Password" name="password" value={formik1.values.password} onChange={formik1.handleChange} onBlur={formik1.handleBlur}></input><br></br>
//             {formik1.touched.password && formik1.errors.password ? <span style={{ color: 'red' }}>{formik1.errors.password}</span> : null}
//             <br></br> */}

//             {/* onBlur is used to get Focus a perticular intput Field.
//        If we use "touched" then onBlur is supplementary used.
//        Otherwise if we toched any one inputfield all the Errors will be shown. */}


//             {/* <button type="submit" id='B' onClick={home}>Submit</button> <br></br> */}
//             <div style={{marginTop:'1%'}}>
//             <text style={{fontSize:18}}>  Not an User? </text>
//             <button onClick={lgn} type="submit" id='a'> 
//             <text style={{fontSize:19}}> Sign up now</text>
//             </button>
//             </div>
           
//         </form>
//         <div style={{marginBottom:'2%'}}>
//           <br></br>
//           <br></br><br></br>
//        </div>
//     </div>
//     );
// };
// export default Login;

import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import OtpInput from 'react-otp-input';
export default function Login() {


//const [otp,setOtp]=useState(new Array(4).fill(""))
  const [otp, setOtp] = useState('')
  const navigate = useNavigate();
   const lgn = () => {
       navigate('/Home')
   }

  const handleChange = (otp) => {
    setOtp(otp )
  }
// const handleChange =(element,index)=>{
//   //setUser({...user,[e.target.name]:e.target.value })
//   if(isNaN(element.value)) return false;

//   setOtp([...otp.map((d,idx)=>(idx === index)? element.value : d)])
//   if(element.nextSibiling){
//     element.nextSibiling.focus();
//   }

// }

  return (
    <>
    <div style={{alignItems:'center',justifyContent:'center',flex:1}}>
      
      <div style={{marginTop:'10%'}}>
        <text style={{fontWeight:'bold',fontSize:25}}>Verify Phone Number</text>
      </div>
      <div style={{marginTop:'4%'}}>
        <text style={{fontSize:20}}> Please enter the verification code </text><br></br>
        <text style={{fontSize:20,marginTop:'30px'}}>we send to your number</text>
      </div>
       
        <div style={{
          marginTop: '5%',
          display: 'flex', alignItems: 'center', justifyContent: "center"
        }}>
          <OtpInput
            inputStyle={{ width: 45,height:35}}
            value={otp}
            onChange={handleChange}
            numInputs={6}
            separator={
              <div >
                <span style={{marginLeft:10}}></span>
              </div>
            } />
       </div>
        <div style={{
          display: "flex", flexDirection: "row",
          flexWrap: "nowrap",
          alignItems: 'center', justifyContent: 'center'
        }}>
          {/* <input style={{ borderWidth: 0, borderBottomWidth: 2, width: 25, alignSelf: 'center' }}
          
          /> <input style={{
            marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
            width: 25, alignSelf: 'center'
          }} /><input style={{
            marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
            width: 25, alignSelf: 'center'
          }} /><input style={{
            marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
            width: 25, alignSelf: 'center'
          }} /> */}
        </div>
      <div style={{marginTop:'5%'}}>
      <button onClick={lgn}  id="BT" type="submit"
       style={{width:'20%',height:40,borderWidth:0,borderRadius:5,
               backgroundColor:'rgb(99, 195, 165)'}}> 
              <text style={{fontSize:21,color:'white'}}> CONFIRM </text>
               </button> 
      </div>
      </div>
      </>
  )
}

// import React, { Component } from 'react'

// export default class Login extends Component {
//   render() {
//     return (
//       <div>
        
//         <div style={{ alignItems: 'center', justifyContent: 'center', flex: 1 }}>

//           <div style={{ marginTop: '10%' }}>
//             <text style={{ fontWeight: 'bold', fontSize: 25 }}>Verify Phone Number</text>
//           </div>
//           <div style={{ marginTop: '4%' }}>
//             <text style={{ fontSize: 20 }}> Please enter the verification code </text><br></br>
//             <text style={{ fontSize: 20, marginTop: '30px' }}>we send to your number</text>
//           </div>

//           <div style={{
//             display: "flex", flexDirection: "row",
//             flexWrap: "nowrap",
//             alignItems: 'center', justifyContent: 'center'
//           }}>
//             <input style={{ borderWidth: 0, borderBottomWidth: 2, width: 25, alignSelf: 'center' }}

//             /> <input style={{
//               marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
//               width: 25, alignSelf: 'center'
//             }} /><input style={{
//               marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
//               width: 25, alignSelf: 'center'
//             }} /><input style={{
//               marginLeft: 5, borderWidth: 0, borderBottomWidth: 2,
//               width: 25, alignSelf: 'center'
//             }} />
//           </div>
//           <div style={{ marginTop: '5%' }}>
//             <button onClick={lgn} id="BT" type="submit"
//               style={{
//                 width: '15%', height: 40, borderWidth: 0, borderRadius: 5,
//                 backgroundColor: 'rgb(99, 195, 165)'
//               }}>
//               <text style={{ fontSize: 21, color: 'white' }}> CONFIRM </text>
//             </button>
//           </div>
//         </div>
        
//         </div>
//     )
//   }
// }
